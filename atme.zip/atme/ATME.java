import java.io.File;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.io.*;
import java.text.SimpleDateFormat;

class PINE implements ActionListener
{
static String ui;
Frame f;
JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,m1,m2,m3;
JPasswordField p1;
JTextField t1;
JButton b1,b2,b3;

static int n=4;
int p=5;
String s1=new String();
PINE()throws IOException
{
JLabel bg=new JLabel(new ImageIcon("mm.jpg"));
f=new Frame("LOGIN PIN");
l1=new JLabel("enter PIN");
l2=new JLabel("NAME");
l3=new JLabel("                                or                                ");
b3=new JButton("!!!~~~~~~>                             welcome to     SBI   atm                                      <~~~~~~!!!  ");
l5=new JLabel("                                                                    ");
l6=new JLabel("                                                                    ");
l7=new JLabel("                                                                    ");
l8=new JLabel("Developed by :     Penujuri Sudharshan ");
l8.setForeground(Color.gray);
m1=new JLabel("                                                                                                                                                      ");
m2=new JLabel("                                                                                                                                                      ");
m3=new JLabel("                                                                                                                                                       ");
p1=new JPasswordField(10);
t1=new JTextField(15);
b1=new JButton("LOGIN");
b2=new JButton("create ACCOUNT");
ImageIcon i1=new ImageIcon("ul.jpg");
JLabel jl=new JLabel(i1);
f.setVisible(true);
f.setSize(1500,1550);

b3.setForeground(Color.blue);
b3.setBackground(Color.yellow);
t1.setForeground(Color.blue);
p1.setForeground(Color.blue);

b1.setForeground(Color.orange);
b1.setBackground(Color.darkGray);
b2.setForeground(Color.darkGray);
b2.setBackground(Color.orange);


f.setLayout(new FlowLayout(FlowLayout.CENTER,560,20));

f.add(b3);
f.add(l5);
f.add(l6);



Panel p2=new Panel();
p2.setLayout(new FlowLayout(FlowLayout.CENTER,20,0));
p2.add(l2);
p2.add(t1);

Panel p3=new Panel();
p3.setLayout(new FlowLayout(FlowLayout.CENTER,20,0));
p3.add(l1);
p3.add(p1);



Panel p5=new Panel();
p5.setLayout(new FlowLayout(FlowLayout.CENTER,560,20));
p5.add(m1);


Panel p6=new Panel();
p6.setLayout(new FlowLayout(FlowLayout.CENTER,560,20));
p6.add(m2);

Panel p4=new Panel();
p4.setLayout(new FlowLayout(FlowLayout.CENTER,560,20));
p4.add(l8);

f.add(p2);
f.add(p3);
f.add(b1);
f.add(l3);
f.add(b2);
f.add(jl);
f.add(p5);
f.add(p4);

b1.addActionListener(this);
b2.addActionListener(this);
p1.addKeyListener(new KeyAdapter(){
				public void keyTyped(KeyEvent ke)
				{
				char pn=ke.getKeyChar();
				if((pn<'0'||pn>'9')&&(pn!='\b')&&(pn!='-')){
				ke.consume();}
				/*else{
				JOptionPane.showMessageDialog(null,"enter DIGITS only");}*/

				}
				});
}


public void actionPerformed(ActionEvent ae)
{


if(b1.equals(ae.getSource()))
{

	try
{
	ui=t1.getText();
	BufferedReader fl=new BufferedReader(new FileReader(ui+".txt"));    
	int c;
	while((c=fl.read())!=-1)
	{
	s1=s1+(char)c;
	}
	n=Integer.parseInt(p1.getText());
	p=Integer.parseInt(s1);
}
catch(Exception e)
{
}


	if(p==n)
	{
	
		try
		{
		new ATME();
		f.setVisible(false);
		}
		catch(Exception e)
		{}
	}
	else
	{
	JOptionPane.showMessageDialog(null,"Invalid  Login........!!  :(");
	f.setVisible(false);
	try{
	new PINE();
	}
	catch(Exception e)
	{}
	}
}

if(b2.equals(ae.getSource()))
{

try{
new CA();
f.setVisible(false);
}catch(Exception e){}
	

}



}
public static void main(String s[])throws IOException 
{
new PINE();
}
}
































class ATME implements ActionListener 
{
static int tm;
Frame f;
JButton b5,b1,b2,b3,b4,b6,b7,b8,b9,b10;


ATME()throws IOException
{
//JOptionPane.showMessageDialog(null,"Hello  "+PINE.ui+"......!!!");
String s1=new String();
f=new Frame("ATM");
ImageIcon i1=new ImageIcon("wd.PNG");
b1=new JButton("with drawel",i1);
ImageIcon i2=new ImageIcon("cb.PNG");
ImageIcon i6=new ImageIcon("ms.jpg");
b2=new JButton("check balance",i6);
ImageIcon i3=new ImageIcon("dps.jpg");
b3=new JButton("Deposit",i3);
ImageIcon i4=new ImageIcon("pc.PNG");
b4=new JButton("pin change",i4);
ImageIcon i5=new ImageIcon("exit.PNG");
b5=new JButton("",i5);
b6=new JButton("mini statement",i2);
ImageIcon i7=new ImageIcon("wddd.jpg");
b7=new JButton("money transfer",i7);
b8=new JButton();
b9=new JButton();
b10=new JButton("Hello    " +PINE.ui+"......!!              welcome to  ATM  extension");
b10.setBackground(Color.darkGray);
b10.setForeground(Color.cyan);

f.setLayout(new FlowLayout(FlowLayout.CENTER,0,80));
f.setVisible(true);
f.setSize(1500,1500);
f.setBackground(Color.darkGray);
f.setForeground(Color.black);

Panel p1=new Panel(new GridLayout(3,2,300,90));
p1.add(b1);
p1.add(b2);
p1.add(b3);
p1.add(b7);
p1.add(b4);
p1.add(b6);
p1.add(b8);
p1.add(b5);
p1.add(b9);

f.add(b10);
f.add(p1);
b1.addActionListener(this);
b2.addActionListener(this);
b3.addActionListener(this);
b4.addActionListener(this);
b5.addActionListener(this);
b6.addActionListener(this);
b7.addActionListener(this);
b8.addActionListener(this);
}
public void actionPerformed(ActionEvent ae)
{

	if(b1.equals(ae.getSource()))
	{	
	new WD();
	f.setVisible(false);
	}
	if(b2.equals(ae.getSource())){
	new CB();
	f.setVisible(false);
	}
	if(b3.equals(ae.getSource())){
	new DP();
	f.setVisible(false);
	}
	if(b4.equals(ae.getSource()))
	{
	try{
	new PM();
	f.setVisible(false);
	}
	catch(Exception e)
	{
	}}
	if(b5.equals(ae.getSource()))
	{
	try{
	f.setVisible(false);
	new PINE();
	}
	catch(Exception e)
	{}}
	if(b6.equals(ae.getSource())){
	new MS();
	f.setVisible(false);}
	if(b7.equals(ae.getSource())){
	try{
	new MT();
	f.setVisible(false);
	}
	catch(Exception e)
	{}
	} 
}
}








class WD implements ActionListener
{
Frame f;
Label l;
JButton b1,b2,b3;
JTextField t1;
String s1=new String();
int p,n,re;
WD()
{
f=new Frame("With Drawel");
l=new Label("enter  MONEY");
t1=new JTextField(10);
b1=new JButton("Proceed");
b2=new JButton("main menu");
b3=new JButton("enter Money  ~~>");

f.setLayout(new BorderLayout());
f.setVisible(true);
f.setSize(1500,730);

f.setBackground(Color.gray);
f.setForeground(Color.green);

b1.setForeground(Color.green);
b1.setBackground(Color.darkGray);
b2.setForeground(Color.green);
b2.setBackground(Color.darkGray);
b3.setForeground(Color.green);
b3.setBackground(Color.darkGray);
JLabel bg=new JLabel(new ImageIcon("wdf.jpg"));

Panel p2=new Panel();
p2.setLayout(new FlowLayout(FlowLayout.CENTER,20,0));
p2.add(b3);
p2.add(t1);
p2.add(b1);
p2.add(b2);

Panel p1=new Panel();
p1.setLayout(new FlowLayout(FlowLayout.CENTER,0,0));
p1.add(bg);


f.add(p2,BorderLayout.NORTH);
f.add(p1,BorderLayout.CENTER);
b1.addActionListener(this);
b2.addActionListener(this);
t1.addKeyListener(new KeyAdapter(){
				public void keyTyped(KeyEvent ke)
				{
				char m=ke.getKeyChar();
				if((m<'0'||m>'9')&&(m!='\b')&&(m!='-'))	
				ke.consume();
				}
				});
}
public void actionPerformed(ActionEvent ae)
{

	try
	{
		BufferedReader fl=new BufferedReader(new FileReader(PINE.ui+"a.txt")); 
		int c;
			while((c=fl.read())!=-1)
			{
			s1=s1+(char)c;
			}
		n=Integer.parseInt(t1.getText());
		p=Integer.parseInt(s1);
	}
	catch(Exception e)
	{}
	if(b1.equals(ae.getSource()))
	{
		if(n<p)
		{
			try{
			re=p-n;
			f.setVisible(false);
			BufferedWriter fw=new BufferedWriter(new FileWriter(PINE.ui+"a.txt"));
			String sre=String.valueOf(re);	
			fw.write(sre);
			JOptionPane.showMessageDialog(null,"transaction SUCCESS remaining BALANCE "+sre );
			new DF();
			fw.close();
			}
			catch(Exception e)
			{
			System.out.println("error "+e);	
			}
			
		}
		else
		{
		JOptionPane.showMessageDialog(null,"In sufficent balance");	
		{
		f.setVisible(false);
		try{
		new WD();
		}catch(Exception e)
		{}
		}
		}
	}
	if(b2.equals(ae.getSource())){
	try{
	f.setVisible(false);
	new ATME(); }
	catch(Exception e)
	{}
	}	

}

}








class DP implements ActionListener
{

Frame f;
Label l;
JButton b1,b2,b3;
JTextField t1;
static int d;
DP()
{
f=new Frame("Deposit");
l=new Label("Deposit money");
l.setForeground(Color.black);
t1=new JTextField(10);
b1=new JButton("Proceed");
b2=new JButton("main menu");
b3=new JButton("Deposit Money   ~~~>");
b3.setBackground(Color.black);
b3.setForeground(Color.white);
f.setLayout(new FlowLayout(FlowLayout.CENTER));
f.setVisible(true);
f.setSize(1500,1500);
//f.setBackground(Color.green);
f.setForeground(Color.darkGray);
JLabel bg=new JLabel(new ImageIcon("mb.jpg"));
f.add(b3);
f.add(t1);
f.add(b1);
f.add(b2);
f.add(bg);
b1.addActionListener(this);
b2.addActionListener(this);
t1.addKeyListener(new KeyAdapter(){
				public void keyTyped(KeyEvent ke)
				{
				char m=ke.getKeyChar();
				if((m<'0'||m>'9')&&(m!='\b')&&(m!='-'))
				ke.consume();
				}
				});

}
public void actionPerformed(ActionEvent ae)
{
           if(b2.equals(ae.getSource()))
           {
	f.setVisible(false);
	try
	{
	new ATME();
	}
	catch(Exception c)
	{}
            }

	if(b1.equals(ae.getSource()))
	{
	d=Integer.parseInt(t1.getText());
	String st=new String();
	int p=0;
	try
	{
		BufferedReader fl=new BufferedReader(new FileReader(PINE.ui+"a.txt"));
		int c;
			while((c=fl.read())!=-1)
			{
			st=st+(char)c;
			}
		p=Integer.parseInt(st);
	}
	catch(Exception e)
	{}
	try
	{
		FileWriter fstream = new FileWriter("Deposit.txt",true);
		BufferedWriter out=new BufferedWriter(new FileWriter(PINE.ui+"a.txt"));
		int t=d+p;
		String s1=String.valueOf(t);
		out.write(s1);
		out.close();
		JOptionPane.showMessageDialog(null,"Deposit success");
		f.setVisible(false);
	 	new DF();
	}
	catch(Exception e)
	{}
	
	}
}
}
//**********************************************************************************
   


class PM implements ActionListener 
{
Frame f;
JButton b1,b2;
JPasswordField t1,t2;
Label l1,l2;
String s1,s2;
PM()throws IOException
{
f=new Frame("PIN CHANGE");
f.setLayout(new FlowLayout(FlowLayout.CENTER,600,30));
f.setVisible(true);
f.setSize(1500,750);
f.setBackground(Color.orange);
f.setForeground(Color.darkGray);
JLabel jl=new JLabel(new ImageIcon("pcc.jpg"));
b1=new JButton("proceed");
b2=new JButton("main menu");
t1=new JPasswordField(10);
t2=new JPasswordField(10);
l1=new Label("enter  OLD   pin");
l2=new Label("enter  NEW   pin");

Panel p1=new Panel();
p1.setLayout(new FlowLayout());
p1.add(l1);
p1.add(t1);

Panel p2=new Panel();
p2.setLayout(new FlowLayout());
p2.add(l2);
p2.add(t2);

Panel p3=new Panel();
p3.setLayout(new FlowLayout());
p3.add(b1);
p3.add(b2);


f.add(p1);
f.add(p2);
f.add(jl);
f.add(p3);

b1.addActionListener(this);
b2.addActionListener(this);
t1.addKeyListener(new KeyAdapter(){
				public void keyTyped(KeyEvent ke)
				{
				char op=ke.getKeyChar();
				if((op<'0'||op>'9')&&(op!='\b')&&(op!='-'))
				ke.consume();
				}
				});
t2.addKeyListener(new KeyAdapter(){
				public void keyTyped(KeyEvent ke)
				{
				char op=ke.getKeyChar();
				if((op<'0'||op>'9')&&(op!='\b')&&(op!='-'))
				ke.consume();
				}
				});



}
public void actionPerformed(ActionEvent ae)
{
s1=t2.getText();
s2=t1.getText();
if(b1.equals(ae.getSource()))	
{
	try
	{
	int pin=Integer.parseInt(s2);
		if(pin==PINE.n)
		{
		s1=t2.getText();
		BufferedWriter fr=new BufferedWriter(new FileWriter(PINE.ui+".txt"));
		for(int i=0	;i<4;i++)
		fr.write(s1.charAt(i));
		fr.close(); 
		JOptionPane.showMessageDialog(null,"pin changed Successfully");	
		f.setVisible(false);
		
		try{
		new PINE();
		JOptionPane.showMessageDialog(null,"verify your PIN onces");	
		}catch(Exception e){}
		
	
		
		}
		else
		{
		JOptionPane.showMessageDialog(null,"reENTER OLD password ");		
		f.setVisible(false);
		new PM();
		}
	}
	catch(Exception e)
	{}
}
if(b2.equals(ae.getSource()))
{
try{
	f.setVisible(false);
	new ATME();
}
catch(Exception e)
{}
}}
}



class CB 
{
String s1=new String();
int p;
CB()
{
	try
	{
		BufferedReader fl=new BufferedReader(new FileReader(PINE.ui+"a.txt"));
		int c;
			while((c=fl.read())!=-1)
			{
			s1=s1+(char)c;
			}
		  p=Integer.parseInt(s1);
		JOptionPane.showMessageDialog(null,"account BALANCE   " +p);
		new DF();
	}
	catch(Exception e)
	{}




}
}






class DF implements ActionListener
{
Frame f;
JButton b1,b2,b3,b4,b5,b6,b7,b8,b9;
DF()
{
f=new Frame("DICISSION");
ImageIcon i1=new ImageIcon("cn.PNG");
ImageIcon i2=new ImageIcon("exit.PNG");
b1=new JButton(i1);
b2=new JButton(i2);
b3=new JButton();
b4=new JButton();
b5=new JButton();
b6=new JButton();
b7=new JButton();
b8=new JButton();
b9=new JButton();
b3.setBackground(Color.black);
b4.setBackground(Color.black);
b5.setBackground(Color.black);
b6.setBackground(Color.black);
b7.setBackground(Color.black);
b8.setBackground(Color.black);
b9.setBackground(Color.black);
//b3=setBackground(Color.black);

f.setVisible(true);
f.setSize(1500,750);
f.setBackground(Color.black);
f.setLayout(new GridLayout(3,3,200,200));
f.add(b4);
f.add(b6);
f.add(b3);
f.add(b1);
f.add(b5);
f.add(b2);
f.add(b7);
f.add(b8);
f.add(b9);
b1.addActionListener(this);
b2.addActionListener(this);
}
public void actionPerformed(ActionEvent ae)
{
	if(b1.equals(ae.getSource()))
	{
		try
		{
		f.setVisible(false);
		new ATME();
		}
		catch(Exception e)
		{}
	}

	if(b2.equals(ae.getSource()))
	{
	f.setVisible(false)	;
	try{
	new PINE();
	}
	catch(Exception e)
	{}
	}
	
}

}




class MS implements ActionListener
{
Frame f;
JTextField t1,t2,t3;
JLabel l1,l2,l3,l4;
JButton b1,b2,b3;
//String s,s1,s2=new String();
String s="",s1="",s2="";
MS()
{
f=new Frame("mini statement");
f.setLayout(new FlowLayout(FlowLayout.CENTER,1000,20));
f.setBackground(Color.yellow);
t1=new JTextField(15);
t2=new JTextField(15);
t3=new JTextField(15);
l1=new JLabel("      Date :");
l2=new JLabel("      Time :");
l3=new JLabel("Balance:");
l4=new JLabel("");
b1=new JButton("        exit      ");
b2=new JButton("main menu");
b3=new JButton("         press here        ");
f.setVisible(true);
f.setSize(1500,750);

Panel p1=new Panel();
p1.setLayout(new FlowLayout());
p1.add(b3);

Panel p2=new Panel();
p2.setLayout(new FlowLayout(FlowLayout.LEFT,20,20));
p2.add(l1);
p2.add(t1);

Panel p4=new Panel();
p4.setLayout(new FlowLayout(FlowLayout.LEFT,20,20));
p4.add(l2);
p4.add(t2);

Panel p5=new Panel();
p5.setLayout(new FlowLayout(FlowLayout.LEFT,20,20));
p5.add(l3);
p5.add(t3);

Panel p3=new Panel();
p3.setLayout(new FlowLayout(FlowLayout.LEFT,20,10));
p3.add(b2);
p3.add(b1); 

f.add(p1);
f.add(p2);
f.add(p3);
f.add(p4);
f.add(p5);
f.add(p3);
b1.addActionListener(this);
b2.addActionListener(this);
b3.addActionListener(this);
}
public void actionPerformed(ActionEvent ae)
{
    if(b1.equals(ae.getSource()))
     {
try{     
f.setVisible(false);
     new PINE();}
catch(Exception e)
{}
     }     
     if(b2.equals(ae.getSource()))
     {
     try{ 
	f.setVisible(false);
                new ATME();
     }
     catch(Exception e)
     {}
      }
     if(b3.equals(ae.getSource()))
     {
	
	
	try
	{
	
		BufferedReader fl=new BufferedReader(new FileReader(PINE.ui+"a.txt"));
		int c,p=0;
			while((c=fl.read())!=-1)
			{
			s=s+(char)c;
			}
		//  p=Integer.parseInt(s);
		File f=new File(PINE.ui+"a.txt");
		SimpleDateFormat sdf1=new SimpleDateFormat("dd~MM~YYYY ");
		SimpleDateFormat sdf2=new SimpleDateFormat("HH : mm : ss");
		s1=sdf1.format(f.lastModified());
		s2=sdf2.format(f.lastModified());
	}
	catch(Exception e)
	{}
        t1.setText(s1);
        t2.setText(s2);
        t3.setText(s);
        }
}}














class MT implements ActionListener
{
Frame f;
JTextField t1,t2;
JButton b1,b2;
JLabel l1,l2,l3;
JComboBox cb;
	MT()
   	{
	f=new Frame("Money transfer");
	t1=new JTextField(15);
	t2=new JTextField(15);
	b1=new JButton("transfer");
	b2=new JButton("Main Menu");
	l1=new JLabel("Beneficiary name");
	l2=new JLabel("requested money");
	l3=new JLabel("Account type");
	String[] str={"-select-","savings","current"};
	cb=new JComboBox(str);

	f.setVisible(true);
	f.setSize(1500,750);
	f.setBackground(Color.yellow);
	f.setLayout(new FlowLayout(FlowLayout.LEFT,500,20));

	Panel p1=new Panel();
	p1.setLayout(new FlowLayout(FlowLayout.LEFT,20,20));
	p1.add(l1);
	p1.add(t1);
	
	Panel p2=new Panel();
	p2.setLayout(new FlowLayout(FlowLayout.LEFT,20,20));
	p2.add(l2);
	p2.add(t2);

	Panel p3=new Panel();
	p3.setLayout(new FlowLayout(FlowLayout.LEFT,20,20));
	p3.add(l3);	
	p3.add(cb);

	Panel p4=new Panel();
	p4.setLayout(new FlowLayout(FlowLayout.LEFT,20,20));
	p4.add(b1);
	p4.add(b2);
	
	f.add(p1);
	f.add(p2);
	f.add(p3);
	f.add(p4);
	b1.addActionListener(this);
	b2.addActionListener(this);
	t2.addKeyListener(new KeyAdapter(){
				public void keyTyped(KeyEvent ke)
				{
				char op=ke.getKeyChar();
				if((op<'0'||op>'9')&&(op!='\b')&&(op!='-'))
				ke.consume();
				}
				});




	}
	
	public void actionPerformed(ActionEvent ae)
	{	

		if(b1.equals(ae.getSource()))
		{
		
	int sm=0,um=0,rb;
	String s3=new String();
                   String s1=t1.getText();
	String s2=t2.getText();
	int mt=Integer.parseInt(s2);
	String gt=new String();
	int tt,tm=0,ta;
	
		 	try
			{
			 BufferedReader in = new BufferedReader(new FileReader(PINE.ui+"a.txt"));	
			int c;	
			while((c=in.read())!=-1)	
			s3=s3+(char)c;
			sm=Integer.parseInt(s3);
 			um=Integer.parseInt(s2);		
				
					
					
					
					
					if(um<=sm)
					{
 					try
					{
					 BufferedReader inn = new BufferedReader(new FileReader(s1+"a.txt"));
					while((tt=inn.read())!=-1)
					gt=gt+(char)tt;
				
					tm=Integer.parseInt(gt);
					}
					catch(Exception e)
					{}
					ta=tm+mt;
					String sz=String.valueOf(ta);
										try{
					 BufferedWriter out = new BufferedWriter(new FileWriter(s1+"a.txt"));
					 out.write(sz);
					 out.close();
				 	}
				 	catch (Exception e)
				 	{
					 System.err.println("Error: " + e.getMessage());
					 }
					JOptionPane.showMessageDialog(null,"money transfered");
					f.setVisible(false);
					new DF();
				}
			}
			catch(Exception e)
			{
			System.err.println(""+e);
			}
			try
			{
			 BufferedWriter out = new BufferedWriter(new FileWriter(PINE.ui+"a.txt"));
			rb=sm-um;
			out.write(String.valueOf(rb));
			out.close();
			}
			catch(Exception e)
			{}
		}	

		if(b2.equals(ae.getSource()))
		{
		try{
		new ATME();
		f.setVisible(false);
		}catch(Exception e){}

		
		}
		



		
	  }
}








class CA implements ActionListener
{
Frame f;
JLabel l6,l1,l2,l3,l4,l5;
JTextField t1,t3,t4,t5;
JPasswordField t2;
JButton b1,b2;
JRadioButton  r1,r2;
JComboBox cb;
CA()
{
f=new Frame("--> Create Account");
f.setVisible(true);
f.setSize(1500,750);
f.setBackground(Color.orange);
f.setForeground(Color.gray);
f.setLayout(new FlowLayout(FlowLayout.	CENTER,500,30));
l1=new JLabel("   create  user  NAME :");
l2=new JLabel("                      set   PIN : ");
l3=new JLabel("   Deposit  min  BAL : ");
l4=new JLabel("           Account  type : ");
t1=new JTextField(15);
t2=new JPasswordField(15);
t3=new JTextField(15);
b1=new JButton("SUBMIT");
b2=new JButton("CANCEL");
l5=new JLabel("enter  AADHAR  no : ");
t4=new JTextField(15);
l6=new JLabel("enter   MOBILE   no : ");
t5=new JTextField(15);
b1.setBackground(Color.orange);
b1.setForeground(Color.darkGray);
b2.setBackground(Color.orange);
b2.setForeground(Color.darkGray);
t1.setForeground(Color.blue);
t2.setForeground(Color.blue);
t3.setForeground(Color.blue);
t4.setForeground(Color.blue);
t5.setForeground(Color.blue);


r1=new JRadioButton("Male");
r2=new JRadioButton("FeMale");
ButtonGroup bg=new ButtonGroup();
bg.add(r1);
bg.add(r2);
String[] str={"-select-","savings","current"};
cb=new JComboBox(str);

Panel p2=new Panel();
p2.setLayout(new FlowLayout(FlowLayout.CENTER,50,0));
p2.add(l1);
p2.add(t1);

Panel p3=new Panel();
p3.setLayout(new FlowLayout(FlowLayout.CENTER,50,0));
p3.add(l2);
p3.add(t2);

Panel p4=new Panel();
p4.setLayout(new FlowLayout(FlowLayout.CENTER,50,0));
p4.add(l3);
p4.add(t3);

Panel p5=new Panel();
p5.setLayout(new FlowLayout(FlowLayout.CENTER,50,0));
p5.add(l4);
p5.add(cb);

Panel p1=new Panel();
p1.setLayout(new FlowLayout(FlowLayout.CENTER,50,0));
p1.add(r1);
p1.add(r2);


Panel p6=new Panel();
p6.setLayout(new FlowLayout(FlowLayout.CENTER,50,0));
p6.add(b1);
p6.add(b2);

Panel p7=new Panel();
p7.setLayout(new FlowLayout(FlowLayout.CENTER,50,0));
p7.add(l5);
p7.add(t4);

Panel p8=new Panel();
p8.setLayout(new FlowLayout(FlowLayout.CENTER,50,0));
p8.add(l6);
p8.add(t5);

f.add(p2);
f.add(p3);
f.add(p4);
f.add(p7);
f.add(p8);
f.add(p1);
f.add(p5);
f.add(p6);


b1.addActionListener(this);
b2.addActionListener(this);
r1.addActionListener(this);
r2.addActionListener(this);
t2.addKeyListener(new KeyAdapter(){
				public void keyTyped(KeyEvent ke)
				{
				 char an=ke.getKeyChar();
				  if((an<'0'||an>'9')&&(an!='\b')&&(an!='-'))
				  ke.consume();		
				  }
			              }
                                 );
t3.addKeyListener(new KeyAdapter(){
				public void keyTyped(KeyEvent ke)
				{
				 char an=ke.getKeyChar();
				  if((an<'0'||an>'9')&&(an!='\b')&&(an!='-'))
				  ke.consume();		
				  }
			              }
                                 );
t4.addKeyListener(new KeyAdapter(){
				public void keyTyped(KeyEvent ke)
				{
				 char an=ke.getKeyChar();
				  if((an<'0'||an>'9')&&(an!='\b')&&(an!='-'))
				  ke.consume();		
				  }
			              }
                                 );

t5.addKeyListener(new KeyAdapter(){
				public void keyTyped(KeyEvent ke)
				{
				char mn=ke.getKeyChar();
				if((mn<'0'||mn>'9')&&(mn!='\b')&&(mn!='-'))
					ke.consume();
					
				}
				}
				);
}

public void actionPerformed(ActionEvent ae)
{
String ui=new String();
String up=new String();
String um=new String();
String umb=new String();
String uad="";

	if(b1.equals(ae.getSource()))
	{
	ui=t1.getText();
	up=t2.getText();
	um=t3.getText();	
	umb=t5.getText();
	uad=t4.getText();
	
	try
	{
	BufferedWriter fin=new BufferedWriter(new FileWriter(ui+".txt"));
	fin.write(up);
	fin.close();
	}
	catch(Exception e){}

	try
	{
	BufferedWriter fin=new BufferedWriter(new FileWriter(ui+"ad.txt"));
	fin.write(uad);
	fin.close();
	}
	catch(Exception e){}

	try
	{
	BufferedWriter fin=new BufferedWriter(new FileWriter(ui+"mb.txt"));
	fin.write(umb);
	fin.close();
	}
	catch(Exception e){}
	
	try
	{
	BufferedWriter fiin=new BufferedWriter(new FileWriter(ui+"a.txt"));
	fiin.write(um);
	fiin.close();
	}
	catch(Exception e){}
	f.setVisible(false);
	JOptionPane.showMessageDialog(null,"acount CREATED");
	try{
	new PINE();
	}catch(Exception e){}
	
	
	}	


	if(b2.equals(ae.getSource()))
	{

	f.setVisible(false);
	try{
	new PINE();
	}catch(Exception e){}

	}




}

}




